import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-theme-layouts',
    templateUrl: './theme-layouts.component.html',
    styleUrls  : ['./theme-layouts.component.scss']
})
export class DocsWorkingWithFuseThemeLayoutsComponent
{
    constructor()
    {
    }
}
