import { Component } from '@angular/core';

@Component({
    selector   : 'docs-directives-fuse-if-on-dom',
    templateUrl: './fuse-if-on-dom.component.html',
    styleUrls  : ['./fuse-if-on-dom.component.scss']
})
export class DocsDirectivesFuseIfOnDomComponent
{
    constructor()
    {
    }
}
