import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-tmp',
  templateUrl: './add-tmp.component.html',
  styleUrls: ['./add-tmp.component.scss']
})
export class AddTmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
