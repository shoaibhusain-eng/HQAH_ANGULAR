import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-tmp',
  templateUrl: './list-tmp.component.html',
  styleUrls: ['./list-tmp.component.scss']
})
export class ListTmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
