import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-tmp',
  templateUrl: './edit-tmp.component.html',
  styleUrls: ['./edit-tmp.component.scss']
})
export class EditTmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
