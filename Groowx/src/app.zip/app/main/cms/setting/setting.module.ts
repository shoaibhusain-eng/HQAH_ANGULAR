import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingRoutingModule } from './setting-routing.module';
import { AddTmpComponent } from './template/add-tmp/add-tmp.component';
import { ListTmpComponent } from './template/list-tmp/list-tmp.component';
import { EditTmpComponent } from './template/edit-tmp/edit-tmp.component';


@NgModule({
  declarations: [AddTmpComponent, ListTmpComponent, EditTmpComponent],
  imports: [
    CommonModule,
    SettingRoutingModule
  ]
})
export class SettingModule { }
