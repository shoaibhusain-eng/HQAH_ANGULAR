import { Component } from '@angular/core';

@Component({
    selector   : 'docs-directives-fuse-mat-sidenav',
    templateUrl: './fuse-mat-sidenav.component.html',
    styleUrls  : ['./fuse-mat-sidenav.component.scss']
})
export class DocsDirectivesFuseMatSidenavComponent
{
    constructor()
    {
    }
}
