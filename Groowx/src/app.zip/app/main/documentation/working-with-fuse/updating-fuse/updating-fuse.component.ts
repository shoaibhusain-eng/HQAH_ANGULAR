import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-updating-fuse',
    templateUrl: './updating-fuse.component.html',
    styleUrls  : ['./updating-fuse.component.scss']
})
export class DocsWorkingWithFuseUpdatingFuseComponent
{
    constructor()
    {
    }
}
