import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-production',
    templateUrl: './production.component.html',
    styleUrls  : ['./production.component.scss']
})
export class DocsWorkingWithFuseProductionComponent
{
    constructor()
    {
    }
}
