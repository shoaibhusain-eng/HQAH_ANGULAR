import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-multi-language',
    templateUrl: './multi-language.component.html',
    styleUrls  : ['./multi-language.component.scss']
})
export class DocsWorkingWithFuseMultiLanguageComponent
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
