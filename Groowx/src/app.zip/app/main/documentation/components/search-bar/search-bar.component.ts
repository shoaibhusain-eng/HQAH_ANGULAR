import { Component } from '@angular/core';

@Component({
    selector   : 'docs-components-search-bar',
    templateUrl: './search-bar.component.html',
    styleUrls  : ['./search-bar.component.scss']
})
export class DocsComponentsSearchBarComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
